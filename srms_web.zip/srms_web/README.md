# Student Record Management System (Flask website)

## Easiest way (Windows)
1. Extract the zip completely (right-click > Extract All).
2. Double-click `start.bat`  (installs Flask, starts the server, opens the browser).

## Run in VS Code
1. File > Open Folder... > choose this `srms_web` folder.
2. Terminal > New Terminal, then:
       pip install flask
       python app.py
3. Open http://127.0.0.1:5000 in your browser (not by double-clicking an .html file).
   Stop the server with Ctrl+C.

## Logins
- Staff   : admin / admin123
- Student : username = roll number (e.g. CS101), password = set by staff
            (blank at creation = the roll number in capitals)

## Files
| File | Part | Purpose |
|------|------|---------|
| app.py | Backend | Flask routes, login, sessions, role checks, CSRF |
| store.py | Backend | Student model, SQLite, add/update/delete/verify rules |
| dsa.py | Backend | Linked list, hash map, merge/quick sort, linear/binary search, benchmark |
| templates/*.html | Frontend | Login, staff dashboard, student page, edit, password, benchmark, error |
| static/style.css | Frontend | Styling |
| static/app.js | Frontend | Delete-confirmation popup |

The app also works if all files sit together in ONE folder (no templates/static
sub-folders), as long as all 8 .html files, style.css and app.js are present.
If a file is missing, app.py prints exactly which one.

`srms.db` and `secret.key` are created automatically on first run. Delete `srms.db` to start with an empty database.
